import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  ID:number;
  Name:string;
  Salary:number;
  Department:string;
  
  title = 'Assignamen-app';

  add(id:number,name:string,salary:number,department:string)
{
 this.ID=id;
 this.Name=name;
 this.Salary=salary;
 this.Department=department;
 let emp=[this.ID, this.Name,this.Salary,this.Department];
 
 alert(emp);
 
 
}
}

