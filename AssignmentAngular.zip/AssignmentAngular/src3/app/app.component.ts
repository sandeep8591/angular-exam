import { Component, OnInit } from '@angular/core';
import { CompileShallowModuleMetadata } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  id:number;
  isUpdate:boolean=false;
  name:string;
  salary:number;
  department:string;
  title = 'Assignament21-app';
  employee=[
    {id:123,Name:'krishna',Salary:111,Department:'hyd'},
    {id:124,Name:'sai',Salary:112,Department:'hyd'},
    {id:125,Name:'krish',Salary:113,Department:'hyd'}
  ];
 addEmployee()
 {
  this.employee.push({id:this.id,Name:this.name,Salary:this.salary,Department:this.department});
}
delete(employee){
  let arr=this.employee.filter(p=>p.id !=employee.id);
  this.employee=arr;
  }
  update(employee){
    this.id=employee.id;
    this.name=employee.name;
    this.salary=employee.salary;
    this.department=employee.department;
    this.isUpdate=true;

  }
  updateDetails(){
    let arr=this.employee.filter(p=>p.id!=this.id);
    arr.push({id:this.id,Name:this.name,Salary:this.salary,Department:this.department});
    this.employee=arr;
    this.isUpdate=false;
  }
}